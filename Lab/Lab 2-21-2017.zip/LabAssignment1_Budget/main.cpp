/* 
 * File: LabAssignment1_Budget
 * Author: Joshua Ludwig
 * Created on February 21, 2017, 11:10am
 * Purpose:  calculate the percentage budget for the military and NASA
 */

//System Libraries Here
#include <iostream>
using namespace std;
//Global Constants
const float PERCENT=100.0f;//Percentage
const float BILLION=1.0e9f;//Conversion to Billions
const float TRILLION=1.0e12f;//Conversion to Trillions
int main(int argc, char** argv) {
    //Declare Variables
    float fedBudg=0.354e13f; //3.54 Trillion $'s 2016
    float milBudg=0.580e9f; //580 Billion $'s 2016
    float nasaBudg=18.5e9f; //18.5 Billion $'s 2016
    float perMil,perNasa;
    
    //Map inputs to outputs or process the data
    perMil=milBudg/fedBudg*PERCENT;
    perNasa=nasaBudg/fedBudg*PERCENT;
   
    //Output the transformed data
    cout<<"Federal Budget  = $"<<fedBudg/TRILLION<<" trillions"<<endl;
    cout<<"Military Budget = $"<<milBudg/BILLION<<" billions"<<endl;
    cout<<"NASA Budget     = $"<<perMil<<"%"<<endl;
    cout<<"Military Budget percentage = "<<perMil<<"%"<<endl;
    cout<<"NASA Budget percentage     = "<<perNasa<<"%"<<endl;
    return 0;
}

