/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on February 16, 2017, 12:31PM
 * Purpose: Find the rate of free fall 
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants
const float GRAVITY=32.174f;//Gravity on Earth Sea-Level ft/sec^2

//Function Prototypes Here

//Execution begins here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float time, distance;
    
    //Initialize variables
    time=1.0f;
    
    //Map inputs to outputs or process the data
    distance=GRAVITY*time*time/2;
    
    //Output Located Here
    cout<<"Free fall of "<< time <<" secs = "<< distance <<" ft "<< endl;

    //Exit
    return 0;
}

