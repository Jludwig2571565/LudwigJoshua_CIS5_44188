/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on March, 9, 2017, 12:01 PM
 * Purpose:  Write a program that asks how many tickets for
 *  each class were sold.
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    string month1, month2, month3;
    float rain1, rain2, rain3, Avg;
    
    
    //Input or initialize values Here
    cout<<"Enter the first month and the rain count(in) "<<endl;
    getline(cin, month1);
    cin>>rain1;
    cin.ignore();
    cout<<"Enter the second month and the rain count(in)"<<endl;
    getline(cin, month2);
    cin>>rain2;
    cin.ignore();
    cout<<"Enter the third month and the rain count(in)"<<endl;
    getline(cin, month3);
    cin>>rain3;
    
   
    //Process/Calculations Here
    Avg = (rain1 + rain2 + rain3)/ 3;
   
    //Output Located Here
    cout<<" The average rainfall for "<<month1<<","<<month2<<" and "<<month3
            <<"is"<<fixed<<setprecision(2)<<Avg<<endl;
   
    //Exit
    return 0;
}

