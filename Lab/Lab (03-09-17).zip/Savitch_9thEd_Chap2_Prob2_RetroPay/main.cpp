/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on March 9, 2017, 11:37 AM
 * Purpose: Calculate salary income  
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float payIncr = 0.076,prevSal,anuSal,monSal,retAct;
    
    
    
    //Input or initialize values Here
    cout<<"Input previous salary income"<<endl;
    cin>>prevSal;
    
    //Process/Calculations Here
    anuSal = (1+ payIncr) * prevSal;
    monSal = anuSal/ 12.0f;
    retAct = (payIncr * prevSal)/ 2.0f;
    
    //Output Located Here
    cout<<"Annual salary is "<<anuSal<<endl;
    cout<<"Monthly salary is "<<monSal<<endl;
    cout<<"The Retro-Active pay is "<<retAct<<endl;
    

    //Exit
    return 0;
}

