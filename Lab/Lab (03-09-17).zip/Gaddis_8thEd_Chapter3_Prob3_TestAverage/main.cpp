/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on March, 9, 2017, 12:01 PM
 * Purpose:  Write a program that asks for test scores and calculates 
 * the average test score.
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float Score1,//Test score 1
          Score2,//Test score 2
          Score3,//Test score 3
          Score4,//Test score 4
          Score5,//Test score 5
          Avg;   //Average test score
    
    //Input or initialize values Here
    cout<<"Enter test score 1"<<endl;
    cin>>Score1;
    cout<<"Enter test score 2"<<endl;
    cin>>Score2;
    cout<<"Enter test score 3"<<endl;
    cin>>Score3;
    cout<<"Enter test score 4"<<endl;
    cin>>Score4;
    cout<<"Enter test score 5"<<endl;
    cin>>Score5;
    
    //Process/Calculations Here
    Avg = (Score1 + Score2 + Score3 + Score4 + Score5)/5;
    
    
    
    //Output Located Here
    cout<<"The Average test score is "<<fixed<<setprecision(1)<<Avg<<endl;

    //Exit
    return 0;
}

