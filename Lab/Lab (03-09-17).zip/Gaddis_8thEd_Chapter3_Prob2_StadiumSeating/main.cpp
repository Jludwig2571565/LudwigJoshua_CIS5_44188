/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on March, 9, 2017, 12:01 PM
 * Purpose:  Write a program that asks how many tickets for
 *  each class were sold.
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float ClassA = 15.00f,
          ClassB = 12.00f,
          classC = 9.00f,
          seatSls;
    float Aseats, Bseats, Cseats;
    
    //Input or initialize values Here
    cout<<"Enter the number of Class A seats purchased"<<endl;
    cin>>Aseats;
    cout<<"Enter the number of Class B seats purchased"<<endl;
    cin>>Bseats;
    cout<<"Enter the number of Class C seats purchased"<<endl;
    cin>>Cseats;
            
    //Process/Calculations Here
    seatSls = Aseats + Bseats + Cseats;
    
    
    //Output Located Here
    cout<<"The total income today from seat purchases is $"<<fixed<<
            setprecision(2)<<seatSls<<endl;

    //Exit
    return 0;
}

