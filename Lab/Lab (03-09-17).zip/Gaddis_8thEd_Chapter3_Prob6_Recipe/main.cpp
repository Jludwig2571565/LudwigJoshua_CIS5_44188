/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on March 9, 2017, 11:26 AM
 * Purpose:  Find the number of cups of ingredients needed for the # of cookies
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float sugar  = 1.5, //1.5 cups of Sugar * R
          flower = 2.75;//1 cup Butter * R
    float recipe;
    int   butter =  1,  //2'3/4 cups of Flower
          cookies = 48; //# of cookies made per recipe   
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    recipe = (sugar * butter * flower * cookies)/cookies;
    //Output Located Here
    cout<<"The number of cups needed is "<<recipe<<endl;

    //Exit
    return 0;
}

