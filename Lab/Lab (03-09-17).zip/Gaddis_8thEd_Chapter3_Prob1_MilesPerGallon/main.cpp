/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on March 9, 2017, 11:49 AM
 * Purpose: Calculate car gas mileage
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float gallons, miles, mpg;
    
    //Input or initialize values Here
    cout<<"Enter the number of gallons a full tank is for your vehicle"<<endl;
    cin>>gallons;//Amount of gas in a vehicle(full)
    cout<<"Enter the number of miles you reach on a full tank of gas"<<endl;
    cin>>miles;//Number of miles the user gets on car
    //Process/Calculations Here
    mpg = miles / gallons;
    //Output Located Here
    cout<<"Your MPG is "<<mpg<<endl;

    //Exit
    return 0;
}

