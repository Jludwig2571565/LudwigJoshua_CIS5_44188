/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on March 14, 2017, 11:37 AM
 * Purpose: Time calculator/converter
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
const int MINUTE = 60;     //How many seconds in a minute
const int HOUR = 60*MINUTE;//How many seconds in a hour
const int DAY = 24*HOUR;   //How many seconds in a day
const int WEEK = 7*DAY;    //How many seconds in a week
const int YEAR = 52*WEEK;  //How many seconds in a year


//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int nSecs;//Number of seconds to convert
    int nYrs,nMnths,nWks,nDays,nHours,nMin;
    //Input or initialize values Here
    cout<<"This program converts seconds to Years/Months/Days/Hours"<<endl;
    cout<<"Input the number of seconds for the conversion/equivalence"<<endl;
    cin>>nSecs;
    
    //Process/Calculations Here
    nYrs=nSecs/YEAR;             //Number of years
    cout<<nSecs/YEAR<<" Years (";
    nSecs-=nYrs*YEAR;            //Subtract the yearly seconds from remaining
    
    nWks=nSecs/WEEK;             //Number of weeks
    cout<<nWks<<" Weeks or ";
    nMnths=nWks*3/13;            //Convert number of weeks to months
    cout<<nMnths<<" Months ) ";
    nSecs-=nWks*WEEK;            //Subtract the weekly seconds from remaining 
    
    nDays=nSecs/DAY;             //Number of days
    cout<<nDays<<" Days ";
    nSecs-=nDays*DAY;            //Subtract the daily seconds from the remaining
    
    nHours=nSecs/HOUR;           //Number of hours         
    cout<<nHours<<" Hours ";
    nSecs-=nHours*HOUR;          //Subtract the hourly seconds from remaining
    
    nMin=nSecs/MINUTE;           //Number of minutes
    cout<<nMin<<" Minutes ";
    
    nSecs-=nMin*MINUTE;          
    cout<<nSecs<< " Seconds ";   //Remaining number of seconds
    //Output Located Here
    
    //Exit
    return 0;
}

