/* 
 * File:   main.cpp
 * Author: Joshua Ludwig
 * Created on March 23, 2017, 12:10 PM
 * Purpose: Menu to be utilized on Hmwk 4
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables

//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char choice;
    
    //Show menu and loop
    do{
        //Display Menu
        cout<<""<<endl;
        cout<<"Type 0 to exit"<<endl;
        cout<<"Type 1 for Problem 1 Sum of Numbers"<<endl;
        cout<<"Type 2 for Problem 2 Characters for the ASCII Codes"<<endl;
        cout<<"Type 3 for Problem 3 Ocean Levels"<<endl;
        cout<<"Type 4 for Problem 4 Calories Burned"<<endl;
        cout<<"Type 5 for Problem 5"<<endl;
        cout<<"Type 6 for Problem 6"<<endl;
        cout<<"Type 7 for Problem 7"<<endl;
        cout<<"Type 8 for Problem 8"<<endl;
        cout<<"Type 9 for Problem 9"<<endl;
        
        //Input choice
        cout<<"Problem ";
        cin>>choice;
        
                
        //Place solutions to problems in switch statement
        switch(choice){
            case'1':{
                cout<<"Solution for problem 1"<<endl;
                int Integer,
                count;
                cout<<"Enter an integer"<<endl;
                cin>>Integer;
                cout<<endl;

                while (Integer < 0){
                    cout<<"ERROR please enter a positive integer"<<endl;
                    cin>>Integer;
                    cout<<endl;
                }

                for (count=0; count <= Integer; count++)
                cout<<count<<endl;

                break;
            }
            case'2':{ 
                cout<<"Solution for problem 2"<<endl;
                unsigned char a;
                for(a=32;a < 128; ++a)
                {
                    cout<<a<< " ";
                    cout<<endl;
                }
                break;
            }
            case'3':{
                cout<<"Solution for problem 3"<<endl;
                float MM=0.75,//Amount of millimeters per year
                    counter,
                    total,
                    yrs;
                for (counter=0; counter <= 5;  ++counter)
                {
                    total=MM*counter;
                    
                    cout<<total<<"mm"<<" ------ "<<counter/2<<"Yrs"<<endl;
                    
                }
                break;
                
            }
            case'4':{
                cout<<"Solution for problem 4"<<endl;
                float calories=3.6,
                      counter,
                      total;
                for (counter=0; counter <= 6; ++counter)
                {
                    total = calories * counter;
                    cout<<total*5<<" ---- "<<counter*5<<"minutes"<<endl;
                }
                
                break;
            }
            case'5':{
                cout<<"Solution for problem 5"<<endl;
                float member=2500,
                    rate,
                    counter,
                    perc = 0.04;
                for (counter=0; counter <= 6; ++counter){
                    rate = member * perc;
                cout<<member + (rate * counter)<<"$"<<" ----- "<<counter<<"yrs"<<endl;
                }
                break;
            }
            case'6':{
                cout<<"Solution for problem 6"<<endl;
                int speed,hours,distance,counter;
                cout<<"What is the speed of the vehicle"<<endl;
                cin>>speed;
                cout<<"How many hours has it traveled"<<endl;
                cin>>hours;
                cout<<"------------------------------"<<endl;
                cout<<"Hours --- Distance Traveled"<<endl;
                
                for (counter=0; counter <= hours; counter++)
                {
                    
                    distance = hours * speed;
                    cout<<counter<<" -------------- "<<speed*counter<<endl;
                }
                break;
            }
            case'7':{
                cout<<"Solution for problem 7"<<endl;
                float penny=0.01, count,days;
                cin>>days;
                for (count=0; count <= days; count++)
                {
                    cout<<count<<penny*2<<endl;
                }
                break;
            }
            case'8':{
                cout<<"Solution for problem 8"<<endl;
                //Set the random number seed
                srand(static_cast<unsigned int>(time(0)));
    
                //Declare variables
                int op1, op2, result, answer;
                char choice;
    
                //Input data
                do{
                    cout<<"Math Tutor"<<endl;
                    cout<<"Choose the operation * / + -"<<endl;
                    cin>>choice;
                    cout<<endl;
                    if(!(choice=='+'||choice=='/'||choice=='-'||choice=='*')){
                        cout<<"Exit the Math Tutor"<<endl;
                    }
        


                    //Map inputs to outputs or process the data
                    switch(choice){
                        case '+':{
                            op1=rand()%900+100;//[100-999]
                            op2=rand()%900+100;//[100-999]
                            answer=op1+op2;//[3 to 4 digit result]
                            break;
                        }
                        case'-':{
                            op1=rand()%900+100;//[100-999]
                            op2=rand()%900+100;//[100-999]
                            answer=op1-op2;//[3 to 4 digit result]
                            break;
                        }
                        case'*':{
                            op1=rand()%90+10;//[10-99]
                            op2=rand()%90+10;//[10-99]
                            answer=op1*op2;//[2 to 4 digit result]
                            break;
                        }
                        case'/':{
                            answer=rand()%90+10;//[10-99]
                            op2=rand()%90+10;//[10-99]
                            op1=answer*op2;//[2 to 3 digit result]
                            break;
                        }
                        default:{
                            cout<<"Bad operator"<<endl;
                            return 1;
                        }
                    }
                    //Output the transformed data
                    cout<<setw(8)<<op1<<endl;
                    cout<<choice<<setw(7)<<op2<<endl;
                    cin>>result;
                    cout<<endl;
                    cout<<((result==answer)?"Correct":"Incorrect")<<endl;
                    cout<<"The answer = "<<answer<<endl;
                    cout<<endl;
                }while(choice=='+'||choice=='/'||choice=='-'||choice=='*');
                                break;
            }
            
            case'9':{
                cout<<"Solution for problem 9"<<endl;
                break;
            }
            default:{
                cout<<"Exit the program"<<endl;
            }
                
        }
        
        
    }while(choice>='1'&&choice<='9');
  
    //Exit
    return 0;
}


